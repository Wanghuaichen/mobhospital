
package com.capricorn;

import android.view.View;
import android.view.View.OnClickListener;


public interface OnRayItemClickListener extends OnClickListener {

	void onClick(View v);
}
